import { readFile, writeFile, readdir } from 'node:fs/promises';
import { dirname, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

/** Emballe les modules ESM locaux dans une import map de data URLs.
 * Aucun compilateur, chargement réseau ou duplication du moteur n'est nécessaire.
 * Les sources acceptent exclusivement des imports statiques relatifs, nommés.
 */
export async function build() {
  const branding = {};
  for (const name of ['logo', 'background', 'mascot']) {
    const bytes = await readFile(resolve(ROOT, `assets/branding/voti-${name}.webp`));
    if (bytes.toString('ascii', 0, 4) !== 'RIFF' || bytes.toString('ascii', 8, 12) !== 'WEBP') throw new Error(`Asset de marque WebP invalide : ${name}`);
    branding[name] = `data:image/webp;base64,${bytes.toString('base64')}`;
  }
  const files = [];
  for (const directory of ['shared', 'web']) {
    for (const entry of await readdir(resolve(ROOT, directory))) {
      if (entry.endsWith('.js')) files.push(`${directory}/${entry}`);
    }
  }
  files.sort();
  const imports = {};
  for (const file of files) {
    let source = await readFile(resolve(ROOT, file), 'utf8');
    if (file === 'web/relay-config.js' && process.env.VOTI_RELAY_URL) {
      const config = { relayId: process.env.VOTI_RELAY_ID || 'voti-local', baseUrl: process.env.VOTI_RELAY_URL };
      const url = new URL(config.baseUrl);
      if (!/^[a-z0-9][a-z0-9_-]{0,63}$/.test(config.relayId) || url.username || url.password || url.search || url.hash ||
        !(url.protocol === 'https:' || (url.protocol === 'http:' && ['127.0.0.1', 'localhost'].includes(url.hostname)))) throw new Error('Configuration relais invalide.');
      source = `export const RELAY_CONFIG = ${JSON.stringify(config)};`;
    }
    source = source.replace(/\bfrom\s+(['"])(\.[^'"\n]+)\1/g, (_match, quote, specifier) => {
      const dependency = relative(ROOT, resolve(ROOT, dirname(file), specifier)).split('\\').join('/');
      if (!files.includes(dependency)) throw new Error(`Import non pris en charge : ${file} → ${specifier}`);
      return `from ${quote}voti/${dependency}${quote}`;
    });
    if (/\bimport\s*\(/.test(source) || /\bfrom\s+['"](?:https?:|\/|\.)/.test(source)) {
      throw new Error(`Import non autonome dans ${file}`);
    }
    imports[`voti/${file}`] = `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
  }
  const template = await readFile(resolve(ROOT, 'web/index.template.html'), 'utf8');
  const css = await readFile(resolve(ROOT, 'web/styles.css'), 'utf8');
  const map = JSON.stringify({ imports }).replaceAll('<', '\\u003c');
  const html = template.replace('/* VOTI_STYLES */', css)
    .replace('<!-- VOTI_MODULES -->', `<script type="importmap">${map}</script>\n  <script type="module">import "voti/web/app.js";</script>`)
    .replace('__VOTI_LOGO__', branding.logo).replace('__VOTI_MASCOT__', branding.mascot)
    .replace('__VOTI_BACKGROUND__', branding.background);
  await writeFile(resolve(ROOT, 'index.html'), html);
  return html;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const html = await build();
  console.log(`Build OK : index.html autonome (${Buffer.byteLength(html)} octets), aucune dépendance.`);
}
